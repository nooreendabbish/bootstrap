set.seed(2)
mu <- 0.798                        ##### given value of mu
n <-20                             ##### sample size
m <-20000                          ##### datasets

D<- array(dim = c(20, m))
dataset <- apply (D, 2, function(x) (abs( rnorm(20, mean=0, sd=1)+ mu )))
dataset_mu <- apply(dataset, 2, mean) ##### calculate each column mean
u_Y_mu <- rep(0, m) ##### initiate values to u_Y_mu
for(i in 1:m)
  {
   u_Y_mu[i] <- pnorm(( dataset_mu[i]- mu ) / sqrt( var(dataset_mu) ) )  ##### get the roots
   }
quantile( u_Y_mu, c(0.01, 0.025,0.05, 0.1, 0.9, 0.95, 0.975, 0.99) )

############ using uniform bootstrap
B <- 1999              ##### times of bootstrap replicate
boots_mu <- rep(0, B)
u_Y_star_mu <- rep(0, B)
for(i in 1:B)
   {
    boots <- sample(dataset_mu, m, replace=T) ##### do 1999 times bootstrapping
    boots_mu[i] <- mean( boots )
    }
v <- var(boots_mu)
for(i in 1:B)
   {
    u_Y_star_mu[i] <- pnorm(( boots_mu[i]- mean(boots_mu) ) / sqrt( v ) )  ##### get the roots
    }
quantile( u_Y_star_mu, c(0.01, 0.025, 0.05, 0.1, 0.9, 0.95, 0.975, 0.99) )

############ using weighted bootstrap ###################having some problem for pj
install.packages("rootSolve")
library(rootSolve)
x <- dataset_mu
model <- function( lamb ) { f= sum ( ( x - mean(x) )/( m - lamb * ( x - mean(x))) ) }
r <- multiroot( f= model, start=1 )
r
lambda <- r$root
pj <- rep(0, m)
for(i in 1:m)
   {
    pj[i] <- 1/ (m- lambda*(x[i]-mean(x)))   ##### find out each weight
    }
pj

boots2_mu <- rep(0, B)
u_Y_cro_mu <- rep(0, B)
for(i in 1:B)
   {
    boots2 <- sample(dataset_mu, size = m, replace = TRUE, prob = pj )
    boots2_mu[i] <- mean( boots2 )
       }
v2 <- var(boots2_mu)
for(i in 1:B)
   {
    u_Y_cro_mu[i] <- pnorm(( boots2_mu[i]- mean(boots2_mu) ) / sqrt( v2 ) )  ##### get the roots
    }
quantile( u_Y_cro_mu, c(0.01, 0.025, 0.05, 0.1, 0.9, 0.95, 0.975, 0.99) )






